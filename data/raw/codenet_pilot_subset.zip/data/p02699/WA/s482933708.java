import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int s = scan.nextInt();
        int w = scan.nextInt();
        if(w >= s / 2){
            System.out.println("unsafe");
        }else{
            System.out.println("safe");
        }
    }
}