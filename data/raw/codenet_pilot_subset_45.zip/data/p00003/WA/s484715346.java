import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

//????¨??§£????????????????????????????????????????????????
//http://judge.u-aizu.ac.jp/onlinejudge/review.jsp?rid=1415909#1 
public class Main {
    private final static String NEG = "NO\n";
    private final static String AFF = "YES\n";
 
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in),1024);
        int number = Integer.parseInt(br.readLine());
        int sides[] = new int[3];
        StringTokenizer tknz;
        StringBuilder builder = new StringBuilder();
 
        for (; 0 < number; number--) {
            tknz = new StringTokenizer(br.readLine());
            for (int i = 0; i < 3; i++) {
                sides[i] = Integer.parseInt(tknz.nextToken());
            }
            Arrays.sort(sides);
            if (sides[0] * sides[1] * sides[2] % 60 != 0) {
                builder.append(NEG);
            } else {
                builder.append(AFF);
            }
        }
        System.out.print(builder);
    }
}